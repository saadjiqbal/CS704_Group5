/***********************************************************************************************//**
 * \file   main.c
 * \brief  Silicon Labs Empty Example Project
 *
 * This example demonstrates the bare minimum needed for a Blue Gecko C application
 * that allows Over-the-Air Device Firmware Upgrading (OTA DFU). The application
 * starts advertising after boot and restarts advertising after a connection is closed.
 ***************************************************************************************************
 * <b> (C) Copyright 2016 Silicon Labs, http://www.silabs.com</b>
 ***************************************************************************************************
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 **************************************************************************************************/

/* Board headers */
#include "init_mcu.h"
#include "init_board.h"
#include "init_app.h"
#include "ble-configuration.h"
#include "board_features.h"

/* Bluetooth stack headers */
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"

/* Libraries containing default Gecko configuration values */
#include "em_emu.h"
#include "em_cmu.h"

/* Device initialization header */
#include "hal-config.h"

#if defined(HAL_CONFIG)
#include "bsphalconfig.h"
#else
#include "bspconfig.h"
#endif

// Mapping STDIO to Virtual COM Port
#include <stdio.h>
#include "retargetserial.h"

/***********************************************************************************************//**
 * @addtogroup Application
 * @{
 **************************************************************************************************/

/***********************************************************************************************//**
 * @addtogroup app
 * @{
 **************************************************************************************************/

#ifndef MAX_CONNECTIONS
#define MAX_CONNECTIONS 4
#endif
uint8_t bluetooth_stack_heap[DEFAULT_BLUETOOTH_HEAP(MAX_CONNECTIONS)];

// Gecko configuration parameters (see gecko_configuration.h)
static const gecko_configuration_t config = {
	.config_flags = 0,
	.sleep.flags = SLEEP_FLAGS_DEEP_SLEEP_ENABLE,
	.bluetooth.max_connections = MAX_CONNECTIONS,
	.bluetooth.heap = bluetooth_stack_heap,
	.bluetooth.heap_size = sizeof(bluetooth_stack_heap),
	.bluetooth.sleep_clock_accuracy = 100, // ppm
	.gattdb = &bg_gattdb_data,
	.ota.flags = 0,
	.ota.device_name_len = 3,
	.ota.device_name_ptr = "OTA",
	#if (HAL_PA_ENABLE) && defined(FEATURE_PA_HIGH_POWER)
		.pa.config_enable = 1, // Enable high power PA
		.pa.input = GECKO_RADIO_PA_INPUT_VBAT, // Configure PA input to VBAT
	#endif // (HAL_PA_ENABLE) && defined(FEATURE_PA_HIGH_POWER)
};

// Flag for indicating DFU Reset must be performed
uint8_t boot_to_dfu = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// MOBILE STATION //////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// RSSI READINGS ///////////////////////////////////////////////////////////////////////////////////////////////////////////
#include <math.h>
#define NUM_BEACONS 20
#define NUM_ANCHORS 4
#define NUM_READINGS 10
#define DIST_METHOD 0
#define BT_BUFFER_SIZE 30
#define MAX_DIST 19*100 // 19m converted to cm

// iBeacon data format: The format of the data packet that the beacons broadcast.
typedef struct {
	uint8_t flagsLen;     /* Length of the Flags field. */
	uint8_t flagsType;    /* Type of the Flags field. */
	uint8_t flags;        /* Flags field. */
	uint8_t mandataLen;   /* Length of the Manufacturer Data field. */
	uint8_t mandataType;  /* Type of the Manufacturer Data field. */
	uint8_t compId[2];    /* Company ID field. */
	uint8_t beacType[2];  /* Beacon Type field. */
	uint8_t uuid[16];     /* 128-bit Universally Unique Identifier (UUID). The UUID is an identifier for the company using the beacon*/
	uint8_t majNum[2];    /* Beacon major number. Used to group related beacons. */
	uint8_t minNum[2];    /* Beacon minor number. Used to specify individual beacons within a group.*/
	uint8_t txPower;      /* The Beacon's measured RSSI at 1 meter distance in dBm. See the iBeacon specification for measurement guidelines. */
} iBeaconStruct;

// Data struct used to store beacon measurement data.
typedef struct {
	uint8_t minValue;
	int8_t RSSI;

	int distance;
	int distanceArray[NUM_READINGS];
	int distanceIndex;
} beaconData;

// Data structs used to store x,y,z data.
typedef struct {
	int16_t x;
	int16_t y;
	int16_t z;
} SRAWDATA;
typedef struct {
	int x;
	int y;
	int z;
} BT_RAWDATA;

/*
// CODE FUNCTIONS TO BE USED TO DETERMINE WHICH BEACON TO PERFORM MULTILATERATION WITH.
// https://stackoverflow.com/questions/3893937/c-array-sorting-tips
void bubbleSort(uint32_t a[NUM_BEACONS]) {
	uint32_t i, j, temp;
	for (i = 0; i < (NUM_BEACONS - 1); ++i) {
		for (j = 0; j < (NUM_BEACONS - 1 - i); ++j ) {
			if (a[j] > a[j+1]) {
				temp = a[j+1];
				a[j+1] = a[j];
				a[j] = temp;
			}
		}
	}
}

void chooseBeacons(beaconData beaconMeasurements[NUM_BEACONS], uint8_t smallestIndex[NUM_ANCHORS]) {
	uint32_t distances[NUM_BEACONS];
	uint8_t i = 0;
	uint8_t j = 0;

	for(i = 0; i < NUM_BEACONS; i++) {
		distances[i] = beaconMeasurements[i].distance;
	}
	for(j = 0; j < NUM_ANCHORS; j++) {
		for(i = 0; i < NUM_BEACONS; i++) {
			// if(i == beaconIndexToIgnore) // Use this to ignore non-responsive beacons.
			if(distances[j] == beaconMeasurements[i].distance) {
				smallestIndex[j] = i;
			}
		}
	}
	return;
}
*/

// MULTILATERATION /////////////////////////////////////////////////////////////////////////////////////////////////////////

// I2C MEASUREMENTS ////////////////////////////////////////////////////////////////////////////////////////////////////////
#define PRINT_I2C 0
#include "i2cspm.h"

// FXOS8700CQ accel/mag register addresses.
#define FXOS8700CQ_SLAVE_ADDR (0x1E << 1)
#define FXOS8700CQ_STATUS 0x00
#define FXOS8700CQ_WHOAMI 0x0D
#define FXOS8700CQ_XYZ_DATA_CFG 0x0E
#define FXOS8700CQ_CTRL_REG1 0x2A
#define FXOS8700CQ_M_CTRL_REG1 0x5B
#define FXOS8700CQ_M_CTRL_REG2 0x5C
#define FXOS8700CQ_WHOAMI_VAL 0xC7
#define FXOS8700CQ_READ_LEN 13

// Function used to write a single byte to a specified address.
uint8_t writeI2CByte(uint16_t slaveAddress, uint8_t registerAddress, uint8_t dataToWrite) {
	I2C_TransferSeq_TypeDef seq;
	uint8_t i2c_write_data[2] = {registerAddress, dataToWrite};

	seq.addr = slaveAddress;
	seq.flags = I2C_FLAG_WRITE;
	seq.buf[0].data = i2c_write_data;
	seq.buf[0].len = 2;
	I2C_TransferReturn_TypeDef result = I2CSPM_Transfer(I2C0, &seq);
	if(result == i2cTransferDone) {
		return 1;
	} else {
		return 0;
	}
}

// Function used to read a single byte from a specified register.
uint8_t readI2CByte(uint16_t slaveAddress, uint8_t registerAddress) {
	I2C_TransferSeq_TypeDef seq;
	uint8_t i2c_write_data[1] = {0};
	uint8_t i2c_read_data[1] = {0};

	seq.addr = slaveAddress;
	seq.flags = I2C_FLAG_WRITE_READ;
	i2c_write_data[0] = registerAddress;
	seq.buf[0].data = i2c_write_data;
	seq.buf[0].len = 1;
	seq.buf[1].data = i2c_read_data;
	seq.buf[1].len = 1;
	I2CSPM_Transfer(I2C0, &seq);
	return i2c_read_data[0];
}

// Function used to read accel and mag data.
int16_t ReadAccelMagnData(SRAWDATA *pAccelData, SRAWDATA *pMagnData) {
	uint8_t Buffer[FXOS8700CQ_READ_LEN]; // read buffer
	I2C_TransferSeq_TypeDef seq;
	seq.addr = FXOS8700CQ_SLAVE_ADDR;
	seq.flags = I2C_FLAG_WRITE_READ;
	seq.buf[0].data = FXOS8700CQ_STATUS;
	seq.buf[0].len = 1;
	seq.buf[1].data = Buffer;
	seq.buf[1].len = FXOS8700CQ_READ_LEN;
	I2C_TransferReturn_TypeDef result = I2CSPM_Transfer(I2C0, &seq);

	if(result != i2cTransferDone) {
		return 0;
	} else {// copy the 14 bit accelerometer byte data into 16 bit words
		pAccelData->x = (int16_t)(((Buffer[1] << 8) | Buffer[2]))>> 2;
		pAccelData->y = (int16_t)(((Buffer[3] << 8) | Buffer[4]))>> 2;
		pAccelData->z = (int16_t)(((Buffer[5] << 8) | Buffer[6]))>> 2;
		// copy the magnetometer byte data into 16 bit words
		pMagnData->x = (Buffer[7] << 8) | Buffer[8];
		pMagnData->y = (Buffer[9] << 8) | Buffer[10];
		pMagnData->z = (Buffer[11] << 8) | Buffer[12];
		return 1;
	}
}

// Function used to initialise accel and mag.
void initI2C() {
	uint8_t buffer = readI2CByte(FXOS8700CQ_SLAVE_ADDR, FXOS8700CQ_WHOAMI);
	if(buffer != FXOS8700CQ_WHOAMI_VAL) {
		printf("\n INIT FAILED 1: Could not read FXOS8700CQ_WHOAMI register.");
		return;
	} else {
		printf("\nINIT SUCCEED 1: Could read %x from FXOS8700CQ_WHOAMI register.", buffer);
	}

	buffer = 0x00;
	if(writeI2CByte(FXOS8700CQ_SLAVE_ADDR, FXOS8700CQ_CTRL_REG1, buffer) != 1) {
		printf("\n INIT FAILED 2: Could not write %x to FXOS8700CQ_CTRL_REG1 register.", buffer);
		return;
	} else {
		printf("\nINIT SUCCEED 2: Could write %x to FXOS8700CQ_CTRL_REG1 register.", buffer);
	}

	buffer = 0x1F;
	if(writeI2CByte(FXOS8700CQ_SLAVE_ADDR, FXOS8700CQ_M_CTRL_REG1, buffer) != 1) {
		printf("\n INIT FAILED 3: Could not write %x to FXOS8700CQ_M_CTRL_REG1 register.", buffer);
		return;
	} else {
		printf("\nINIT SUCCEED 3: Could write %x to FXOS8700CQ_M_CTRL_REG1 register.", buffer);
	}

	buffer = 0x20;
	if(writeI2CByte(FXOS8700CQ_SLAVE_ADDR, FXOS8700CQ_M_CTRL_REG2, buffer) != 1) {
		printf("\n INIT FAILED 4: Could not write %x to FXOS8700CQ_M_CTRL_REG2 register.", buffer);
		return;
	} else {
		printf("\nINIT SUCCEED 4: Could write %x to FXOS8700CQ_M_CTRL_REG2 register.", buffer);
	}

	buffer = 0x01;
	if(writeI2CByte(FXOS8700CQ_SLAVE_ADDR, FXOS8700CQ_XYZ_DATA_CFG, buffer) != 1) {
		printf("\n INIT FAILED 5: Could not write %x to FXOS8700CQ_XYZ_DATA_CFG register.", buffer);
		return;
	} else {
		printf("\nINIT SUCCEED 5: Could write %x to FXOS8700CQ_XYZ_DATA_CFG register.", buffer);
	}

	buffer = 0x0D;
	if(writeI2CByte(FXOS8700CQ_SLAVE_ADDR, FXOS8700CQ_CTRL_REG1, buffer) != 1) {
		printf("\n INIT FAILED 6: Could not write %x to FXOS8700CQ_CTRL_REG1 register.", buffer);
		return;
	} else {
		printf("\nINIT SUCCEED 6: Could write %x to FXOS8700CQ_CTRL_REG1 register.", buffer);
	}
}

// MAIN ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * @brief  Main function
 */
int main(void) {
	initMcu(); // Initialize device
	initBoard(); // Initialize board
	initApp(); // Initialize application
	gecko_init(&config); // Initialize stack
	RETARGET_SerialInit(); // Initialize serial communications

	printf("\n\n\n*** New Mobile Run: ***\n\n\n");

	// RSSI READINGS ///////////////////////////////////////////////////////////////////////////////////////////////////////////
	int index = 0;

	// Array of beacon data measurements.
	beaconData beaconMeasurements[NUM_BEACONS];
	for(index = 0; index < NUM_BEACONS; index++) {
		beaconMeasurements[index].RSSI = -1;

		for(beaconMeasurements[index].distanceIndex = 0; beaconMeasurements[index].distanceIndex < NUM_READINGS; beaconMeasurements[index].distanceIndex++) {
			beaconMeasurements[index].distanceArray[beaconMeasurements[index].distanceIndex] = MAX_DIST;
		}
		beaconMeasurements[index].distance = MAX_DIST;
		beaconMeasurements[index].distanceIndex %= NUM_READINGS;

		// Using minor values of beacons to create array index from 0-19.
		if(index <= 9) {
			beaconMeasurements[index].minValue = index + 5;
		} else {
			beaconMeasurements[index].minValue = index + 90;
		}
	}

	// Array of beacon locations.
	BT_RAWDATA beaconLocation[NUM_BEACONS];

	// REPLACE LINES BELOW WITH VALUES FROM PYTHON SCRIPT.
	beaconLocation[0].x = 750; beaconLocation[0].y = 1796; beaconLocation[0].z = 109;
	beaconLocation[1].x = 1057; beaconLocation[1].y = 826; beaconLocation[1].z = 163;
	beaconLocation[2].x = 0; beaconLocation[2].y = 1568; beaconLocation[2].z = 172;
	beaconLocation[3].x = 0; beaconLocation[3].y = 935; beaconLocation[3].z = 172;
	beaconLocation[4].x = 589; beaconLocation[4].y = 285; beaconLocation[4].z = 134;
	beaconLocation[5].x = 1057; beaconLocation[5].y = 1460; beaconLocation[5].z = 174;
	beaconLocation[6].x = 58; beaconLocation[6].y = 0; beaconLocation[6].z = 160;
	beaconLocation[7].x = 602; beaconLocation[7].y = 1358; beaconLocation[7].z = 265;
	beaconLocation[8].x = 602; beaconLocation[8].y = 775; beaconLocation[8].z = 265;
	beaconLocation[9].x = 73; beaconLocation[9].y = 1900; beaconLocation[9].z = 244;
	beaconLocation[10].x = 0; beaconLocation[10].y = 1235; beaconLocation[10].z = 172;
	beaconLocation[11].x = 602; beaconLocation[11].y = 1075; beaconLocation[11].z = 265;
	beaconLocation[12].x = 662; beaconLocation[12].y = 645; beaconLocation[12].z = 265;
	beaconLocation[13].x = 1057; beaconLocation[13].y = 976; beaconLocation[13].z = 163;
	beaconLocation[14].x = 328; beaconLocation[14].y = 275; beaconLocation[14].z = 200;
	beaconLocation[15].x = 0; beaconLocation[15].y = 535; beaconLocation[15].z = 172;
	beaconLocation[16].x = 770; beaconLocation[16].y = 1596; beaconLocation[16].z = 190;
	beaconLocation[17].x = 972; beaconLocation[17].y = 1156; beaconLocation[17].z = 265;
	beaconLocation[18].x = 1057; beaconLocation[18].y = 485; beaconLocation[18].z = 200;
	beaconLocation[19].x = 530; beaconLocation[19].y = 1900; beaconLocation[19].z = 244;

	// Start scanning for bluetooth devices (beacons).
	while(gecko_cmd_le_gap_start_discovery(le_gap_phy_1m, le_gap_discover_observation)->result != 0);

	// I2C MEASUREMENTS ////////////////////////////////////////////////////////////////////////////////////////////////////////
	if(PRINT_I2C == 1) {
		initI2C(); // Initialise the I2C settings.
	}
	SRAWDATA accelData; // Store accel data.
	SRAWDATA magData; // Store mag data.

	while (1) {
		/* Event pointer for handling events */
		struct gecko_cmd_packet* evt;

		/* Check for stack event. */
		evt = gecko_wait_event();

		/* Handle events */
		iBeaconStruct *dataPacket;
		switch (BGLIB_MSG_ID(evt->header)) {

			// EVENT GENERATED ON RESPONSE FROM SCAN.
			case gecko_evt_le_gap_scan_response_id:
				/*
				if(PRINT_I2C == 1) {
					ReadAccelMagnData(&accelData, &magData);
					printf("\n\nAccelData: x=%d, y=%d, z=%d", accelData.x, accelData.y, accelData.z);
					printf("\nMagData: x=%d, y=%d, z=%d", magData.x, magData.y, magData.z);
				}
				*/

				// READING DATA PACKET FROM BEACONS.
				dataPacket = (iBeaconStruct*) evt->data.evt_le_gap_scan_response.data.data;
				if((dataPacket->majNum[0] == 0x03) && (dataPacket->majNum[1] == 0x87)) {
					// Using minor values of beacons to create array index from 0-19.
					index = dataPacket->minNum[1];
					if(index <= 14) {
						index = index - 5;
					} else {
						index = index - 90;
					}

					// CALCULATING DISTANCE TO BEACON IN CM FROM RSSI VALUE.
					int8_t tempRSSI = (int8_t)evt->data.evt_le_gap_scan_response.rssi;
					int8_t C = dataPacket->txPower;
					double  testDistance;

					if(DIST_METHOD == 1) { // Method One:
						// RSSI = -10nlog10(d) + C
						// log10(d) = ((RSSI-C)/(-10n))
						// 10 ^ (((RSSI - C)/-10n)) = d
						double n = 0.8;
						testDistance = (double)tempRSSI;
						testDistance -= (double)C;
						testDistance /= (-10.0*n);
						testDistance = (pow(10, testDistance));
						testDistance *= 100.0;

					} else if(DIST_METHOD == 2) { // Method Two:
						// https://stackoverflow.com/questions/20416218/understanding-ibeacon-distancing
						testDistance = (double)C;
						testDistance -= (double)tempRSSI;
						testDistance /= 10.0;
						testDistance = (pow(10, testDistance));
						testDistance = sqrt(testDistance);
						testDistance *= 100.0;
					}

					// STORING THE CALCULATED DISTANCES INTO THE BEACON STRUCT.
					if((DIST_METHOD == 1) || (DIST_METHOD == 2)) {
						// Filtering out the distances that exceed the room length.
						if(testDistance < MAX_DIST) {
							beaconMeasurements[index].RSSI = tempRSSI;

							// Storing new reading into the array.
							beaconMeasurements[index].distanceArray[beaconMeasurements[index].distanceIndex] = testDistance;
							beaconMeasurements[index].distanceIndex++;
							beaconMeasurements[index].distanceIndex %= NUM_READINGS;

							// Average out all readings within the array.
							int innerIndex = 0;
							for(innerIndex = 0; innerIndex < NUM_READINGS; innerIndex++) {
								beaconMeasurements[index].distance += beaconMeasurements[index].distanceArray[innerIndex];
							}
							beaconMeasurements[index].distance /= NUM_READINGS;
							printf("\nDistance[%d]: %d", index, beaconMeasurements[index].distance);
						}
					}

					// SENDING DATA TO BASE STATION VIA BLUETOOTH.
					char bufferBT[BT_BUFFER_SIZE];
					sprintf(bufferBT, "P%05dX%05dY", index, index);
					gecko_cmd_gatt_server_write_attribute_value(gattdb_CoordValue,0,strlen(bufferBT),bufferBT);
				}
				break;

			/* This boot event is generated when the system boots up after reset.
			* Do not call any stack commands before receiving the boot event.
			* Here the system is set to start advertising immediately after boot procedure. */
			case gecko_evt_system_boot_id:

				/* Set advertising parameters. 100ms advertisement interval.
				 * The first parameter is advertising set handle
				 * The next two parameters are minimum and maximum advertising interval, both in
				 * units of (milliseconds * 1.6).
				 * The last two parameters are duration and maxevents left as default. */
				gecko_cmd_le_gap_set_advertise_timing(0, 160, 160, 0, 0);

				/* Start general advertising and enable connections. */
				gecko_cmd_le_gap_start_advertising(0, le_gap_general_discoverable, le_gap_connectable_scannable);
				break;

			case gecko_evt_le_connection_closed_id:

				/* Check if need to boot to dfu mode */
				if (boot_to_dfu) {
				  /* Enter to DFU OTA mode */
				  gecko_cmd_system_reset(2);
				} else {
				  /* Restart advertising after client has disconnected */
				  gecko_cmd_le_gap_start_advertising(0, le_gap_general_discoverable, le_gap_connectable_scannable);
				}
				break;

			/* Events related to OTA upgrading
			 ----------------------------------------------------------------------------- */

			/* Check if the user-type OTA Control Characteristic was written.
			* If ota_control was written, boot the device into Device Firmware Upgrade (DFU) mode. */
			case gecko_evt_gatt_server_user_write_request_id:

				if (evt->data.evt_gatt_server_user_write_request.characteristic == gattdb_ota_control) {
					/* Set flag to enter to OTA mode */
					boot_to_dfu = 1;
					/* Send response to Write Request */
					gecko_cmd_gatt_server_send_user_write_response(evt->data.evt_gatt_server_user_write_request.connection, gattdb_ota_control, bg_err_success);

					/* Close connection to enter to DFU OTA mode */
					gecko_cmd_le_connection_close(evt->data.evt_gatt_server_user_write_request.connection);
				}
				break;

			default:
				break;
		}
	}

	return 0;
}

/** @} (end addtogroup app) */
/** @} (end addtogroup Application) */
