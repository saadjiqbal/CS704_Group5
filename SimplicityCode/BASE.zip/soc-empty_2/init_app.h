#ifndef INIT_APP_H
#define INIT_APP_H

#ifdef __cplusplus
extern "C" {
#endif

void initApp(void);

#ifdef __cplusplus
}
#endif

#endif // INIT_APP_H
