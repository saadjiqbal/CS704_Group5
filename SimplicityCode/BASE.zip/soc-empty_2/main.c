/***********************************************************************************************/
/**
 * \file   main.c
 * \brief  Silicon Labs Empty Example Project
 *
 * This example demonstrates the bare minimum needed for a Blue Gecko C application
 * that allows Over-the-Air Device Firmware Upgrading (OTA DFU). The application
 * starts advertising after boot and restarts advertising after a connection is closed.
 ***************************************************************************************************
 * <b> (C) Copyright 2016 Silicon Labs, http://www.silabs.com</b>
 ***************************************************************************************************
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 **************************************************************************************************/

/* Board headers */
#include "init_mcu.h"
#include "init_board.h"
#include "init_app.h"
#include "ble-configuration.h"
#include "board_features.h"

/* Bluetooth stack headers */
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"

/* Libraries containing default Gecko configuration values */
#include "em_emu.h"
#include "em_cmu.h"

/* Device initialization header */
#include "hal-config.h"

#if defined(HAL_CONFIG)
	# include "bsphalconfig.h"
#else
	# include "bspconfig.h"
#endif

/***********************************************************************************************/
/**
 * @addtogroup Application
 * @{
 **************************************************************************************************/

/***********************************************************************************************/
/**
 * @addtogroup app
 * @{
 **************************************************************************************************/

# ifndef MAX_CONNECTIONS
	# define MAX_CONNECTIONS 4
# endif
uint8_t bluetooth_stack_heap[DEFAULT_BLUETOOTH_HEAP(MAX_CONNECTIONS)];

// Gecko configuration parameters (see gecko_configuration.h)
static const gecko_configuration_t config = {
    .config_flags = 0,
    .sleep.flags = SLEEP_FLAGS_DEEP_SLEEP_ENABLE,
    .bluetooth.max_connections = MAX_CONNECTIONS,
    .bluetooth.heap = bluetooth_stack_heap,
    .bluetooth.heap_size = sizeof(bluetooth_stack_heap),
    .bluetooth.sleep_clock_accuracy = 100, // ppm
    .gattdb = & bg_gattdb_data,
    .ota.flags = 0,
    .ota.device_name_len = 3,
    .ota.device_name_ptr = "OTA",
    #if (HAL_PA_ENABLE) && defined(FEATURE_PA_HIGH_POWER)
        .pa.config_enable = 1, // Enable high power PA
    .pa.input = GECKO_RADIO_PA_INPUT_VBAT, // Configure PA input to VBAT
    #endif // (HAL_PA_ENABLE) && defined(FEATURE_PA_HIGH_POWER)
};

// Flag for indicating DFU Reset must be performed
uint8_t boot_to_dfu = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// BASE STATION ////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Mapping STDIO to Virtual COM Port
#include <stdio.h>
#include "retargetserial.h"

/**
 * @brief  Main function
 */
void main(void) {
    initMcu(); // Initialize device
    initBoard(); // Initialize board
    initApp(); // Initialize application
    gecko_init( & config); // Initialize stack
    RETARGET_SerialInit(); // Initialize serial communications

    int index = 0;
    int isSame = 1;
    uint8 connectionID = -1;
    uint32 coordServiceID = -1;
    uint8 mobileStationAddress[6] = {0xC0,0x06,0xA9,0x57,0x0B,0x00}; // MAC address of mobile station.
    uint8 coordServiceUUID[16] = {0x67,0xc8,0x88,0x20,0xf4,0x17,0x4a,0xba,0xd3,0x4c,0xae,0x5d,0x88,0xf2,0x07,0x52}; // UUID of service.
    uint8 coordCharUUID[16] = {0x88,0x1d,0x9f,0xb1,0x11,0x74,0x0f,0x9f,0x69,0x44,0x5a,0x76,0x66,0x44,0x24,0xa0}; // UUID of characteristic.

    // Start scanning for bluetooth devices (beacons).
    uint16 result = -1;
	result = gecko_cmd_le_gap_start_discovery(le_gap_phy_1m, le_gap_discover_observation)->result;
	if(result != 0) {
		printf("\nAttempt to start searching for devices: %u", result);
	}

    while (1) {
    	/* Event pointer for handling events */
        struct gecko_cmd_packet *evt;

        /* Check for stack event. */
        evt = gecko_wait_event();

        /* Handle events */
        switch (BGLIB_MSG_ID(evt->header)) {
			// Attempt to discover the mobile station.
			case gecko_evt_le_gap_scan_response_id:

				// Go through MAC address of device to match against mobile station address.
				isSame = 1;
				for (index = 0; index < 6; index++) {
					if (mobileStationAddress[index] != evt-> data.evt_le_gap_scan_response.address.addr[index]) {
						isSame = 0;
					}
				}

				// If it matches, then attempt to connect to mobile station.
				if (isSame == 1) {
					result = gecko_cmd_le_gap_connect(evt->data.evt_le_gap_scan_response.address, evt-> data.evt_le_gap_scan_response.address_type, le_gap_phy_1m)-> result;
					if(result != 0) {
						printf("\nAttempt to connect to mobile station: %u", result);
					}
				}
				break;

			// If connection was established
			case gecko_evt_le_connection_opened_id:
				connectionID = evt->data.evt_le_connection_opened.connection;
				result = gecko_cmd_gatt_discover_primary_services_by_uuid(connectionID, 16, coordServiceUUID)->result;
				if(result != 0) {
					printf("\nAttempt to find the desired service by UUID: %u", result);
				}
				break;

			// Discovering the coordinate service of the mobile station.
			case gecko_evt_gatt_service_id:
				coordServiceID = evt->data.evt_gatt_service.service;
				result = gecko_cmd_gatt_read_characteristic_value_by_uuid(connectionID, coordServiceID, 16, coordCharUUID)->result;
				if(result != 0) {
					printf("\nAttempt to read the value of the characteristic: %u", result);
				}
				break;

			// Reading the value returned from the coordinate characteristic.
			case gecko_evt_gatt_characteristic_value_id:
				printf("\nMobile Station: ");
				for (index = 0; index < evt->data.evt_gatt_characteristic_value.value.len; index++) {
					printf("%c", evt->data.evt_gatt_characteristic_value.value.data[index]);
				}
				break;

			case gecko_evt_gatt_procedure_completed_id:
				if((connectionID != -1) && (coordServiceID != -1)) {
					result = gecko_cmd_gatt_read_characteristic_value_by_uuid(connectionID, coordServiceID, 16, coordCharUUID)->result;
					if(result != 0) {
						printf("\nAttempt to read the value of the characteristic: %u", result);
					}
				} else if(evt->data.evt_gatt_procedure_completed.result != 0) {
					if((connectionID != -1) && (coordServiceID != -1)) {
						result = gecko_cmd_gatt_read_characteristic_value_by_uuid(connectionID, coordServiceID, 16, coordCharUUID)->result;
						if(result != 0) {
							printf("\nAttempt to read the value of the characteristic: %u", result);
						}
					} else if(connectionID == -1) {
						result = gecko_cmd_le_gap_start_discovery(le_gap_phy_1m, le_gap_discover_observation)->result;
						if(result != 0) {
							printf("\nAttempt to start searching for devices: %u", result);
						}
					} else if(coordServiceID == -1) {
						result = gecko_cmd_gatt_discover_primary_services_by_uuid(connectionID, 16, coordServiceUUID)->result;
						if(result != 0) {
							printf("\nAttempt to find the desired service by UUID: %u", result);
						}
					}
				}
				break;

				/* This boot event is generated when the system boots up after reset.
				 * Do not call any stack commands before receiving the boot event.
				 * Here the system is set to start advertising immediately after boot procedure. */
			case gecko_evt_system_boot_id:

				/* Set advertising parameters. 100ms advertisement interval.
				 * The first parameter is advertising set handle
				 * The next two parameters are minimum and maximum advertising interval, both in
				 * units of (milliseconds * 1.6).
				 * The last two parameters are duration and maxevents left as default. */
				gecko_cmd_le_gap_set_advertise_timing(0, 160, 160, 0, 0);

				/* Start general advertising and enable connections. */
				gecko_cmd_le_gap_start_advertising(0, le_gap_general_discoverable, le_gap_connectable_scannable);
				break;

			case gecko_evt_le_connection_closed_id:
				connectionID = -1;
				coordServiceID = -1;
				result = gecko_cmd_le_gap_start_discovery(le_gap_phy_1m, le_gap_discover_observation)->result;
				if(result != 0) {
					printf("\nAttempt to start searching for devices: %u", result);
				}

				/* Check if need to boot to dfu mode */
				if (boot_to_dfu) {
					/* Enter to DFU OTA mode */
					gecko_cmd_system_reset(2);
				} else {
					/* Restart advertising after client has disconnected */
					gecko_cmd_le_gap_start_advertising(0, le_gap_general_discoverable, le_gap_connectable_scannable);
				}
				break;

				/* Events related to OTA upgrading
				   ----------------------------------------------------------------------------- */

				/* Check if the user-type OTA Control Characteristic was written.
				 * If ota_control was written, boot the device into Device Firmware Upgrade (DFU) mode. */
			case gecko_evt_gatt_server_user_write_request_id:

				if (evt->data.evt_gatt_server_user_write_request.characteristic == gattdb_ota_control) {
					/* Set flag to enter to OTA mode */
					boot_to_dfu = 1;
					/* Send response to Write Request */
					gecko_cmd_gatt_server_send_user_write_response(evt->data.evt_gatt_server_user_write_request.connection, gattdb_ota_control, bg_err_success);

					/* Close connection to enter to DFU OTA mode */
					gecko_cmd_le_connection_close(evt->data.evt_gatt_server_user_write_request.connection);
				}
				break;

			default:
				break;
        }
    }
}

/** @} (end addtogroup app) */
/** @} (end addtogroup Application) */
